package com.example.tcc.database

import androidx.room.RoomDatabase
import androidx.room.Database
import com.example.tcc.database.dao.UserDao
import com.example.tcc.database.entities.UserEntity

@Database(
    entities = [UserEntity::class], // Colocar as Entidades
    version = 1
)
abstract class TCCDataBase: RoomDatabase() {
    abstract fun userDao(): UserDao
}
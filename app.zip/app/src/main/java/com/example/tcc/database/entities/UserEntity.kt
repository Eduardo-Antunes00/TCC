package com.example.tcc.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity//Transforma o objeto em uma tabela no BD
data class UserEntity (
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val nome: String,
    val email: String,
    val senha: String,
    val cidadePreferidaId: Int,
    val cordX: Double,
    val cordY: Double
    )
//COLOCAR AS CHAVES ESTRANGEIRAS
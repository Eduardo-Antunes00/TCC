package com.example.tcc.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tcc.database.TCCDataBase
import com.example.tcc.database.dao.UserDao
import com.example.tcc.database.entities.UserEntity
import kotlinx.coroutines.launch

class UsuarioViewModel(private val usuarioDao: UserDao) : ViewModel() {

    private val _usuarios = MutableLiveData<List<UserEntity>>()
    val usuarios: LiveData<List<UserEntity>> get() = _usuarios

    // Buscar todos os usuários
    fun carregarUsuarios() {
        viewModelScope.launch {
            val lista = usuarioDao.getTodos()
            _usuarios.postValue(lista)
        }
    }

    // Inserir um novo usuário
    fun adicionarUsuario(usuario: UserEntity) {
        viewModelScope.launch {
            usuarioDao.inserir(usuario)
            carregarUsuarios() // atualiza a lista
        }
    }
}

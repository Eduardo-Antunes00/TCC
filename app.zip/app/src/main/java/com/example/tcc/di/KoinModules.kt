package com.example.tcc.di

import androidx.room.DatabaseView
import androidx.room.Room
import com.example.tcc.database.TCCDataBase
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val storageModule = module {
    single {
    Room.databaseBuilder(
        androidContext(),
        TCCDataBase::class.java, "TCCDataBase.db"
    ).build()
}
    single {
        get<TCCDataBase>().userDao()
    }
}
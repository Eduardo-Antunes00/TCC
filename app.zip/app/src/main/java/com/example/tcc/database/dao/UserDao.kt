package com.example.tcc.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.tcc.database.entities.UserEntity

@Dao//Colocar os comandos em SQL
interface UserDao {

        @Insert
        suspend fun inserir(usuario: UserEntity)

        @Query("SELECT * FROM UserEntity")
        suspend fun getTodos(): List<UserEntity>

        @Query("SELECT * FROM UserEntity WHERE email = :email AND senha = :senha LIMIT 1")
        suspend fun login(email: String, senha: String): UserEntity?

}